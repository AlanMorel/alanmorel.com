if npc.getPlayer().hasItem("bone", 10) and npc.getPlayer().hasItem("bacon", 10):
    npc.sayNext("Wow, you did it " + name + "! You collected what I asked. Now I can finally make myself a nice hot meal. As promised in return, here is a [BLUE]Map[] which you can use to navigate the following cave, and some exp to help you.")
    npc.giveItem("bone", -10)
    npc.giveItem("bacon", -10)
    npc.giveItem("map", 1)
    npc.giveExp(1000)
    npc.sayOk("Thank you so much for your help young traveler. Stay safe, and good luck in there.")
else:
    npc.sayNext("Hello, " + name + ". My name is Boulder and I need some help. I'm hungry and I'm running a bit low on food.")
    npc.sayNext("I was wondering if you could help me collect [SCARLET]10 bones and 10 pieces of bacon[]. It should not take somebody of your caliber much time to collect it all but it will help me immensely.")
    choice = npc.sayYesNo("In return, I will give you a [BLUE]Map[] which you need to explore the following cave, and some exp for your troubles. So do you think you can help me out?")
    if choice:
        npc.sayOk("Great! This means a lot to me. I'll be here waiting for you here whenever you have those items.")
    else:
        npc.sayOk("Are you sure? I think the [BLUE]Map[] could be really useful for you. In any case, I'll be here if you change your mind.")
