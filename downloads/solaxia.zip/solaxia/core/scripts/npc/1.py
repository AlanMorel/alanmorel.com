if npc.getPlayer().hasItem("scythe", 10):
    npc.sayNext("Perfect. This is just enough [SCARLET]scythes[] to get us out of here. Crafting an [BLUE]Emblem of Valor[] takes 5 each, so we have enough to make one for both of us.")
    npc.giveItem("scythe", -10)
    npc.giveItem("emblem", 1)
    npc.sayOk("Thank you so much for your help. I can finally get out of here. I hope you make it out as well.")
else:
    npc.sayNext("What a brave person you are. You're standing on haunted territory and are still alive. I don't know about you, but I'm trying to get out of here.")
    choice = npc.sayYesNo("If you could help me collect [SCARLET]10 scythes[], I can craft us both an [BLUE]Emblem of Valor[]. Without it, we're stuck here for good. I hope you realize we should probably not be here. So what do you say, will you get us both out of here?")
    if choice:
        npc.sayOk("That is really good to hear. I hope you get those 10 scythes, and fast! I'm getting really cold here.")
    else:
        npc.sayOk("You're out of your mind! I guess you're going to stay here for good!")
