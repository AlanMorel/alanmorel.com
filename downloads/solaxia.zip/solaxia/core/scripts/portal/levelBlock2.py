if portal.getPlayer().getLevel() >= 12:
    portal.getPlayer().warp(7, 0)
else:
    portal.sayOk("These grounds are way too powerful for you. You will need to be at least level 12 to proceed.")