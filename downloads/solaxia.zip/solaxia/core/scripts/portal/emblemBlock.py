if portal.getPlayer().hasItem("emblem", 1):
    portal.sayNext("Congrats! You have completed the playthrough of this build!")
    portal.sayOk("You will now be blessed with [SCARLET]Valor[], a very powerful buff for [BLUE]5 minutes[]. During this time, you will be immensely powerful and will be able to use the [SCARLET]Explosion[] ability, by pressing the 'E' key. Thank you for playing!")
    portal.getPlayer().applyBuff("valor")
    portal.giveItem("emblem", -1);
    portal.playSong("mainmenu")
else:
    portal.sayOk("These icy grounds can only be escaped if you have an [BLUE]Emblem of Valor[].")