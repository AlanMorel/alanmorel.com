if portal.getPlayer().getLevel() >= 5:
    portal.getPlayer().warp(2, 0)
else:
    portal.sayOk("Sorry, you must be at least level 5 to proceed.")