if portal.getPlayer().hasItem("map", 1):
    portal.getPlayer().warp(5, 0)
else:
    portal.sayOk("The monsters inside this cave are very dangerous. You will need a [BLUE]Map[] to navigate this cavern.")